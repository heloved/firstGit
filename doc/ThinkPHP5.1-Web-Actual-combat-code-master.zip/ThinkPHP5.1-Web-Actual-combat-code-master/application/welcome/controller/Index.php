<?php

namespace app\welcome\controller;

use think\Controller;

class Index extends Controller
{
	public function home()
	{
		return view();
	}

	public function help()
	{
		return view();
	}

	public function about()
	{
		return view();
	}
} 