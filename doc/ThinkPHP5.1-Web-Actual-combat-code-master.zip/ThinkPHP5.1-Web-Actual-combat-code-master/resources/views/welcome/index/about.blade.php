
@extends('_layout.default') 
@section('title', '关于') 
@section('content')
<section class="jumbotron text-center">
    <div class="container">
        <h1 class="jumbotron-heading">关于页面</h1>
    </div>
</section>
@stop
                                        