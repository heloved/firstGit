
@extends('_layout.default') 
@section('title', '帮助') 
@section('content')
<section class="jumbotron text-center">
    <div class="container">
        <h1 class="jumbotron-heading">帮助页面</h1>
    </div>
</section>
@stop
                                        