@extends('_layout.default') 
@section('title', '主页') 
@section('content')
<section class="jumbotron text-center">
    <div class="container">
        <h1 class="jumbotron-heading">欢迎你，我的朋友</h1>
    </div>
</section>
@stop